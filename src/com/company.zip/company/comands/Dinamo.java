package com.company.comands;

public class Dinamo extends Teams {

    public Dinamo(String name, int maxRunDistance,
                  int maxJumpHeight, int maxSwimDistance) {
        super(name, maxRunDistance, maxJumpHeight, maxSwimDistance);
    }

}