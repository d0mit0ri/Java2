package com.company.comands;

public class CSKA extends Teams {

    public CSKA(String name, int maxRunDistance,
                int maxJumpHeight, int maxSwimDistance) {
        super(name, maxRunDistance, maxJumpHeight, maxSwimDistance);
    }


}