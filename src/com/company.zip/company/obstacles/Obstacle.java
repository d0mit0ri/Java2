package com.company.obstacles;

import com.company.Participant;

public abstract class Obstacle {

    public abstract void doIt(Participant animal);
}